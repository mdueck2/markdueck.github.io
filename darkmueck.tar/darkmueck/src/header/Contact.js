import React from 'react';
import './Contact.scss';
import GitHubLogo from './GitHub-Mark-32px.png';
import LinkedInLogo from './LI-In-Bug.png';

const Contact = () => (
    <div className='contact'>
        <a href='https://github.com/mdueck2' target='_blank' rel='noopener noreferrer'>
            <img className='contact-img' src={GitHubLogo} alt='GitHub'/>
        </a>
        <a href='https://www.linkedin.com/in/mark-dueck/' target='_blank' rel='noopener noreferrer'>
            <img className='contact-img' src={LinkedInLogo} alt='LinkedIn'/>
        </a>
    </div>
);

export default Contact;