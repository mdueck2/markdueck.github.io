import React from 'react';
import logo from './dm.png';
import './Logo.scss';

const Logo = () => (
    <a className='logo-wrapper' href='localhost:3000'>
        <img className='logo' src={logo} alt='DM Logo'/>
    </a>
)

export default Logo;