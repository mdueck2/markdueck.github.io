import React from 'react';
import './Header.scss';
import Logo from './Logo';
import Contact from './Contact';

const Header = () => (
    <header className='header'>
        <Logo />
        <Contact />
    </header>
);

export default Header;