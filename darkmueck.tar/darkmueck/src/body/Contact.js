import React from 'react';

const Contact = () => (
    <div className='contact' id='contact'>
        Contact Me
    </div>
)

export default Contact;