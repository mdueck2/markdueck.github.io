import React, {useState} from 'react';
import './Body.scss';
import Navigation from './Navigation';
import Profile from './Profile';
import Education from './Education';
import Experience from './Experience';
import Contact from './Contact';
import Content from './Content';

const Body = ({children}) => {

	const [page, setPage] = useState('Profile');

	const changePage = () => {
        if (page === 'Profile'){
			return <Profile />;
        } else if (page === 'Education'){
            return <Education />;
        } else if (page === 'Experience'){
            return <Experience />;
        } else if (page === 'Contact'){
            return <Contact />;
        } else {
            return 'NO CONTENT';
        }
    }

    return (
        <body className="body">
            <Navigation changePage={setPage}/>
            <Content>
                {changePage()}
            </Content>
        </body>
    )
};

export default Body;