import React from 'react';

const Profile = () => (
    <div className='profile ' id='profile'>
        Who am I?
    </div>
)

export default Profile;