import React from 'react';

const Experience = () => (
    <div className='experience' id='experience'>
        Personal Experience
    </div>
)

export default Experience;