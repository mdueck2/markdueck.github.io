import React from 'react';

const Education = () => (
    <div className='education' id='education'>
        My Education
    </div>
)

export default Education;