import React from 'react';
import './Navigation.scss';

const Navigation = ({changePage}) => (
    <div className="nav-btns">
        <button className='nav-btn btn-slide-line center' onClick={() => changePage('Profile')}>Profile</button>
        <button className='nav-btn btn-slide-line center' onClick={() => changePage('Experience')}>Experience</button>
        <button className='nav-btn btn-slide-line center' onClick={() => changePage('Education')}>Education</button>
        <button className='nav-btn btn-slide-line center' onClick={() => changePage('Contact')}>Contact</button>
    </div>
)

export default Navigation;