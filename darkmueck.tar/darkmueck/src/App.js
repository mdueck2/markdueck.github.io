import React from 'react';
import './App.scss';
import Header from './header/Header';
import Body from './body/Body';
import Footer from './footer/Footer';

const App = () => (
	<div className='app'>
		<Header />
		<Body />
		<Footer />
	</div>
)

export default App;
