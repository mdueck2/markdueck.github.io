import React, {useEffect} from 'react';
import './Game.scss';

const Game = () => {

    


    useEffect(() => {
        let img = new Image();
        img.src = 'http://clipart-library.com/images/6cr5jbo9i.png';
        img.onload = function() {
            init();
        }

        let canvas = document.getElementById("stickGuy");
        let ctx = canvas.getContext('2d');

        const scale = .15;
        const width = 180;
        const height = 340;
        
        const scaledWidth = width * scale;
        const scaledHeight = height * scale;

        
        let frameCount = 0;
        let currentDirection = 3;
        let currentCanvasX = 0;
        let currentFrame = 0;

        function step() {
            frameCount++;
            if (frameCount < 5){
                window.requestAnimationFrame(step);
                return;
            }

            frameCount = 0;
            ctx.clearRect(0,0,canvas.width, canvas.height);
            ctx.canvas.width = window.innerWidth;
            ctx.canvas.height = window.innerHeight;
            drawFrame(currentFrame%9, currentFrame%8 ,currentCanvasX,130);
            currentFrame++;
            if (currentFrame >= 70){
                currentFrame = 0;
            }

            currentCanvasX+=scaledWidth/2;
            if (currentCanvasX >= canvas.width){
                currentCanvasX = 0;
            }

            if (currentDirection >= 4){
                currentDirection = 0;
            }
            window.requestAnimationFrame(step);
        }

        function drawFrame(frameX, frameY, canvasX, canvasY){
            ctx.drawImage(img, frameX * width, frameY * height, width, height, canvasX, canvasY, scaledWidth, scaledHeight);
        }

        function init() {
            window.requestAnimationFrame(step);
        }

    });

    return (
        <div className='game'>
            <canvas id='stickGuy'>

            </canvas>
        </div>
    )
}

export default Game;